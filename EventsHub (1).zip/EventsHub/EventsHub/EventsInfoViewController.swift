//
//  EventsInfoViewController.swift
//  EventsHub
//
//  Created by Pravallika Mummadi on 11/20/23.
//

import UIKit

class EventsInfoViewController: UIViewController {

    @IBOutlet weak var event: UILabel!
    
    @IBOutlet weak var venue: UILabel!
    
    @IBOutlet weak var date: UILabel!
    
    @IBOutlet weak var time: UILabel!
    
    @IBOutlet weak var address: UILabel!
    
    @IBOutlet weak var by: UILabel!
    
    @IBOutlet weak var img: UIImageView!
    
    var type=""
    var vn=""
    var dt=""
    var tm=""
    var add=""
    var sponsered=""
    var imgOl="nil"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        event.text! += type
        venue.text! += vn
        date.text! += dt
        time.text! += tm
        address.text! += add
        by.text! += sponsered
        img.image = UIImage(named: imgOl)
    }
    
    @IBAction func register(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
