//
//  ViewController.swift
//  EventsHub
//
//  Created by Pravallika Mummadi on 11/20/23.
//

import UIKit

class HomeScreenViewController: UIViewController {

    var imageView=""
    
    var fes=""
    var venue=""
    var date=""
    var time=""
    var address=""
    var sponsor=""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn(_ sender: Any) {
        imageView = "1"
        fes="Ganesh Chaturthi"
        venue="Univeristy Parking Lot 29"
        date="08/12/2024"
        time="08:00 PM"
        address="Centennial Dr, Maryville, MO 64468"
        sponsor="ISA"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(transition == "resultSegue")
        {
            let destination = segue.destination as! EventsInfoViewController
            destination.type = fes
            destination.vn = venue
            destination.dt = date
            destination.tm = time
            destination.add = address
            destination.sponsered = sponsor
            destination.imgOl = imageView
        }
    }
}

